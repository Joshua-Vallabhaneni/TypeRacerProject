import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.io.IOException;
import javax.swing.text.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.ArrayList;
import java.nio.file.*;

/**
*TypeRacer class instantiates and sets necessary graphical elements for type racer layout
*note: user has to click space for game to terminatePosition
*/
public class TypeRacer
{
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); //obtains the size of the screen
    //DefaultHighlighterPainter constructor code snippet researched from docs.oracle.com
    private Highlighter.HighlightPainter current = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW); 
    //yellow color represents current word that the user is on
    private Highlighter.HighlightPainter right = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
    //green color represents words that the user have gotten right
    private Highlighter.HighlightPainter wrong = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
    //red color represents words that the user have gotten wrong
    private JTextArea typeArea = new JTextArea(""); 
    private JTextArea promptArea = new JTextArea();
    private Highlighter promptHighlighter = promptArea.getHighlighter();
    private ArrayList<Getter> words = new ArrayList<Getter>();
    private String[] prompt; //String arrays for the texts
    private String text = "";
    private JFrame frame = new JFrame();
    private JPanel promptHolder = new JPanel();
    private JPanel gameInfo = new JPanel();
    private JPanel progressBars = new JPanel();
    private JPanel typeHolder = new JPanel();
    private JProgressBar computer, user;
    private JLabel WPMLabel = new JLabel("Current WPM: 0");
    private JLabel correctness = new JLabel("     Accuracy: _%");
    private int numberOfWords, WPM, numOfWords, numCorrect, computerWords, time;
    private int numOfChar = 0;
    private String typed = "";
    private double accuracy;
    private boolean notEndofText=true;
    private boolean timerStarted, computerStarted = false;
    private AnalyzerForText reader; //ion
    private StatRecorder writer;//oin
   
    /**
    *TypeRacer constuctor uses instantiated fields from class and sets them to necessary dimensions for the visual display
    */
    public TypeRacer(String readName, String writeName) throws IOException, BadLocationException 
    {
        AnalyzerForText tr = new AnalyzerForText(readName);
        reader = new AnalyzerForText(writeName);
        writer = new StatRecorder(writeName);
        prompt = tr.readText();
        progressBars.setLayout(new GridLayout(1,4));
        computer = new JProgressBar(0,prompt.length);
        computer.setStringPainted(true);
        computer.setString("Computer (60WPM) Progress");
        computer.setForeground(Color.BLUE);
        user = new JProgressBar(0,prompt.length);
        user.setStringPainted(true);
        user.setString("User Progress");
        user.setForeground(Color.PINK);
        progressBars.add(computer); //progress bar set for competitive element of code
        progressBars.add(user); //progress bar set for my element of the code
        frame.setLayout(new BorderLayout());
        frame.add(promptHolder, BorderLayout.NORTH); //prompt is displayed at the top
        frame.add(typeHolder, BorderLayout.SOUTH); //user types below the prompt
        frame.add(gameInfo, BorderLayout.WEST);  
        frame.add(progressBars, BorderLayout.EAST);  
        gameInfo.setLayout(new GridLayout(1,4));
        promptHolder.add(promptArea);
        typeHolder.add(typeArea);
        gameInfo.add(WPMLabel);
        gameInfo.add(correctness);
        promptArea.setLineWrap(true);  //setLineWrap method wraps by going to the next line
        promptArea.setWrapStyleWord(true); //setWrapStyleWord avoids groups of words from separating and keeps them intact
        typeArea.setLineWrap(true);
        typeArea.setWrapStyleWord(true);
        typeArea.addKeyListener(new typeListener());
        typeArea.setPreferredSize(new Dimension(screenSize.width*1/2, screenSize.height*3/8));
        promptArea.addKeyListener(new typeListener());
        promptArea.setEditable(false); //prevent the user from entering text into the wrong text field
        promptArea.setPreferredSize(new Dimension(screenSize.width*1/2,screenSize.height*3/8));
        typeArea.setEditable(false);
        for(String c: prompt) //for each loop accesses a prompt and adds the individual words into seperate elements within the words arraylist
        {
            text = text + c + " ";
            words.add(new Getter(numOfChar, numOfChar + c.length(), null, c));
            numOfChar += (c.length() + 1);
        }
        numOfChar = 0;
        promptArea.setText(text);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(0,0,1000,660);
        frame.setResizable(true);
        frame.setVisible(true);
        typeArea.setFont(new Font("Serif", Font.PLAIN, 20));
        promptArea.setFont(new Font("Serif", Font.PLAIN, 20));
        correctness.setFont(new Font("Verdana", Font.PLAIN, 16));
        WPMLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        computer.setFont(new Font("Verdana", Font.PLAIN, 14));
        user.setFont(new Font("Verdana", Font.PLAIN, 14));
    }

    /**
    *highlightWord method ensures that appropriate highlight is covered for right, wrong or current word
    */
    public void highlightWord() throws BadLocationException
    {
        if(words.get(numberOfWords).getToken() != null) 
        {
            promptHighlighter.removeHighlight(words.get(numberOfWords).getToken()); //removeHighlight method ensures that highlights in specified object, or in this case element of arraylist is removed
            words.get(numberOfWords).setToken(null);
        }
        words.get(numberOfWords).setToken(promptHighlighter.addHighlight(words.get(numberOfWords).getStart(), words.get(numberOfWords).getEnd(), current)); //addHighlight method adds highlight to specified object element of arraylist
    }
    /**
    *spacePressed method dictates the actions that occur when a user clicks the spacebar
    *detects incorrect and correct words using wordCheck method and then highlights words green or red 
    *the user should only be directed to be typing on one word at a time, not be able to go back to previous words
    *whenever the user clicks the spacebar it moves onto the next word 
    */
    public void spacePressed()
    {
        if(notEndofText) //checks boolean condition to see if text is completed
        {
            String checkWord = typed.substring(previousSpace(typed) + 1, typed.length());
            if(wordCheck(checkWord)) //checks if the word the user types is accurate and corresponds with the word in the prompt
            {
                numCorrect++; //number of correct words increments
                try 
                {
                    promptHighlighter.removeHighlight(words.get(numberOfWords).getToken());
                    words.get(numberOfWords).setToken(null);
                    words.get(numberOfWords).setToken(promptHighlighter.addHighlight(words.get(numberOfWords).getStart(), words.get(numberOfWords).getEnd(), right)); //since the word is detected as correct, the token in the arraylist that corresponds with the correct word is turned green as indication
                }
                catch(Exception e) {}
            }
            else 
            {
                try 
                {
                    promptHighlighter.removeHighlight(words.get(numberOfWords).getToken());
                    words.get(numberOfWords).setToken(null);
                    words.get(numberOfWords).setToken(promptHighlighter.addHighlight(words.get(numberOfWords).getStart(),words.get(numberOfWords).getEnd(),wrong)); //since the word is not detected as correct and the user has typed the spacebar indicating that they have moved on to the next word, the token in the arraylist that corresponds with the correct word is turned red as indication
                }
                catch(Exception e) 
                {
                }
            }
            numberOfWords++; //overall count for number of words increments
            if(numberOfWords == prompt.length)//if statement detects if words user has typed matches with the number of words in prompt
            {
                notEndofText = false;
            }
            user.setString("User Progress");
            user.setValue(numberOfWords);
            WPM = (int)(numCorrect/(((double)time)/60)); //calulates words per minute by dividing total correct words over the running time
            WPMLabel.setText("WPM:" + WPM);
            accuracy = ((double)numCorrect)/(numberOfWords); //calculates fraction of words that are accurate by simply dividing number of correct words at the instanc with the number of total words at the instance
            correctness.setText("Accuracy: " + (int)(accuracy*100) + "%   ");
            try 
            {
                highlightWord();
            }
            catch(Exception e)
            {
                notEndofText = false;
            }
            numOfWords++;
            if(notEndofText == false) //endOfGame method is run once it is detected that the user has typed until the end of the prompt 
            {
                endOfGame();
            }
        }        
    }

    /**
    *endOfGame method recordes the users final WPM and Accuracy and into txt file
    */
    public void endOfGame()
    {
        try 
        {
            writer.write("Final Recorded WPM: " + WPM + " Final Recorded Accuracy: " + (int)(accuracy*100) + "%");
        }
        catch(Exception e) 
        {
        }
    }

    
    /**
    *wordCheck method returns whether or not the word the user has typed is the same as the word in the prompt
    */
    public boolean wordCheck(String string)
    {
        return (string.equals(prompt[numberOfWords]));
    }
    /**
    *previousSpace method detects for a space so and returns the index of this space. Detects the end of a token as an empty space stands as a delimiter
    */
    public int previousSpace(String string)
    {
        for(int i = string.length() - 1; i>=0; i--) 
        {
            if(string.charAt(i) == ' ')
            {
                return i;
            }
        }
        return -1;
    }
    /**
    *startRecordingTime method runs whenver a key is pressed
    *the thread only starts to occur if the program has not started yet
    *occurs/records time until the user reaches the end of the prompt
    */
    public void startRecordingTime()
    {
        if(!timerStarted)
        {
            new Thread(() -> {
                while(true) 
                {
                    if(notEndofText) 
                    {
                        time++;
                        if(time%60 < 10) 
                        WPM = (int)(numCorrect/(((double)time)/60));
                        WPMLabel.setText("WPM: " + WPM);
                        accuracy = ((double)numCorrect)/(numberOfWords);
                        correctness.setText("Accuracy: " + (int)(accuracy*100) + "%");
                        try 
                        {
                            Thread.sleep(1000);
                        }
                        catch(Exception e)
                        {
                        }
                    }
                }   
            }).start();
        timerStarted = true;
        }
    }
    /**
    *computerStart method runs whenever a key is pressed
    *the thread only starts to occur if the program has not started yet
    *causes computer progress bar to go up a constant amount so that the user can compare
    */
    public void computerStart() 
    {
        if(!computerStarted) 
        {
            computerStarted = true;
            new Thread(() -> {
                while(computerWords < prompt.length) 
                {
                    try{
                        Thread.sleep(1000);
                    }
                    catch(Exception e) {}
                    computerWords++;
                    computer.setValue(computerWords);
                    computer.setString("Computer Progress");
                }
                computer.setString("Computer Progress");
            }).start();
        }
    }
    /**
    *typeListener class is responsible for actions that occur when user types various keys
    */
    private class typeListener implements KeyListener 
    {
            /**
            *keyPressed method programs actions for the different keys that are pressed
            */
        public void keyPressed(KeyEvent e)
        {
            if(e.getKeyCode() == 8) //keyCode 8 is reponsible for backspace, does not allow the user to go back to a previous word if they had gotten it correct already
            {
                if(typed.charAt(typed.length() - 1) == ' ') 
                {
                    typed = typed.substring(0, typed.length() - 1);
                    numberOfWords--;
                    String checkWord = typed.substring(previousSpace(typed) + 1, typed.length());
                    if(wordCheck(checkWord))
                    {
                        typed = typed + " ";
                        numberOfWords++;
                    }
                    else 
                    {
                        promptHighlighter.removeHighlight(words.get(numberOfWords + 1).getToken());
                        try 
                        {
                            highlightWord();
                        }
                        catch(Exception x)
                        {
                        }
                        numOfWords--;
                    }
                }
                else if(typed.length() > 0) 
                {
                    typed = typed.substring(0, typed.length() - 1);
                }   
            }
            else if(e.getKeyCode() == 32) //the methods for threading at initiated if the spacebar is clicked on 
            {
                startRecordingTime();
                computerStart();
                spacePressed();
                typed = typed + " ";
            }
            else if((e.getKeyCode() >= 44 && e.getKeyCode() <= 111) || (e.getKeyCode() >127 && e.getKeyCode() <= 263) || (e.getKeyCode() >512 && e.getKeyCode() <= 523)) //keycodes for all other characters found online: start the threads if character is clicked
            {
                startRecordingTime();
                computerStart();
                typed += e.getKeyChar();
            }
            typeArea.setText(typed);         
        }
        public void keyReleased(KeyEvent e)
        {
        }
        public void keyTyped(KeyEvent e)
        {   
        }
    }
    public static void main(String[] args) throws IOException, BadLocationException 
    {
        TypeRacer racer = new TypeRacer("Prompts.txt", "Stats.txt");
        racer.highlightWord();
    }
}

class AnalyzerForText  
{
    private String nameOfFile;
    private File file;
    private BufferedReader bufferedReader;
    private Scanner scanner;
    /**
    * code adopted from research, reads a random line from the list of prompts and adds each word to a string array then returns said array
    */
    public AnalyzerForText(String nameOfFile) throws IOException 
    {
        this.nameOfFile = nameOfFile;
        file = new File(nameOfFile);
        bufferedReader = new BufferedReader(new FileReader(file));
        scanner = new Scanner(new File(nameOfFile));
    }
    public String[] readText() throws IOException 
    {
        Path path = Paths.get(nameOfFile);
        long numLines = Files.lines(path).count();
        int randomLine = (int)(Math.random() * numLines);
        String line = "";
        for(int x = 0; x < randomLine; x++)
        {
            bufferedReader.readLine();
        }
        line = bufferedReader.readLine();
        return(line.split(" "));
    }
    public static void main(String[] args) throws IOException 
    {
    }
}

class Getter
{
    private int beginPosition;
    private int terminatePosition;
    private Object highlightToken;
    private String word;
    public Getter(int start, int end, Object tag, String word) 
    {
        beginPosition = start;
        terminatePosition = end;
        highlightToken = tag;
        this.word = word;
    }
    /**
    *get method returns the beginning position of the word
    */
    public int getStart()
    {
        return beginPosition;
    }
    /**
    *get method returns the ending position of the word
    */
    public int getEnd()
    {
        return terminatePosition;
    }
    /**
    *get method returns the token of the highlight
    */
    public Object getToken()
    {
        return highlightToken;
    }
    /**
    *get method returns the String word object
    */
    public String getWord()
    {
        return word;
    }
    /**
    *get method returns the token from arraylist of Word
    */
    public void setToken(Object obj)
    {
        highlightToken = obj;
    }
}

class StatRecorder 
{
    /**
    *Java FileWriter class is a part of the java.io package
    *Code adopted from journaldev
    */
    private String nameOfFile;
    private BufferedWriter bufferedwrite;
    private FileWriter filewrite;
    private PrintWriter printwrite;
    public StatRecorder(String nameOfFile) throws IOException 
    {
        this.nameOfFile = nameOfFile;
    }
    /**
    *writes and records the WPM and Accuracy numbers to the txt file
    */
    public void write(String str) throws IOException
    {
        filewrite = new FileWriter(nameOfFile, true); 
        bufferedwrite = new BufferedWriter(filewrite); 
        printwrite = new PrintWriter(bufferedwrite); 
        printwrite.println(str); 
        printwrite.flush();  //flush method immediately writes the data to the output file.
        printwrite.close(); 
        bufferedwrite.close(); 
        filewrite.close();   
    }
    public static void main(String[] args) throws IOException 
    {
    }
}